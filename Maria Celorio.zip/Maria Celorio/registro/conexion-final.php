<?php

// Realizar la conexión con la base de datos que hemos creado en PhpMyAdmin. https://www.youtube.com/watch?v=f0yJDiKdsJc

// DATOS PARA CONECTARSE EN REMOTO CON LA BASE DE DATOS CREADA DESDE EL PhpMyAdmin DE TU HOSTING

$host='localhost'; // Este es el nombre del Host Server. Te lo debe proporcionar tu Hosting
$user='id9586802_maria'; // Usuario para acceder a tu servidor de bases de datos MySQL. También te lo debe indicar tu Hosting. A veces este nombre lo elige el usuario
$pw= 'Celorio09'; // Tu contraseña del usuario para manejar tus bases de datos MySQL
$db= 'id9586802_registro'; // Nombre de la Base de Datos de tipo MySQL creada mediante tu Hosting. También te lo debe indicar tu Hosting. A veces este nombre lo elige el usuario

?>